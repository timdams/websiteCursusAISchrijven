# API-referentie

## excal.js

```js
const { createCanvas, C } = require('./excal');
const c = createCanvas(BREEDTE, HOOGTE);
```

`createCanvas` zet een SVG-canvas op met offwhite achtergrond en Caveat als font.

### Kleuren (`C`)

| Constante | Hex | Gebruik |
|---|---|---|
| `C.RED` | `#FF0000` | accentranden, pijlen die iets aanduiden |
| `C.RED_DARK` | `#B30000` | zwaardere randen, labeltekst in ballonnen |
| `C.RED_LIGHT` | `#FFE5E5` | vulkleur accentvlakken |
| `C.GRAY` | `#4D4D4D` | gewone tekst en lijnen |
| `C.OFFWHITE` | `#f8f9fa` | achtergrond |
| `C.WHITE` | `#ffffff` | vulling van gewone boxen |
| `C.BOX_TOP` / `C.BOX_SIDE` | `#fbe9e9` / `#f3d4d4` | boven- en zijvlak van 3D-doosjes |

Gebruik nooit losse hex-waarden. Staat een kleur er niet bij, vraag het dan.

### Tekst

```js
c.txt(x, y, tekst, size = 36, color = C.GRAY, weight = 400, anchor = 'middle')
c.lines(x, y, [regels], size = 32, color, weight, anchor, lh = 1.05)
c.txtSegs(x, y, [{t, color, weight}], size = 32, anchor = 'start')   // gemengde kleuren op 1 regel
```

`y` is de **basislijn**, niet de bovenkant. Voor verticaal centreren in een box van hoogte
`h`: `y = boxY + h/2 + size * 0.34`. `anchor` is `'start'`, `'middle'` of `'end'`.

Caveat is smal: reken ongeveer `0,42 x fontgrootte` per teken om te schatten of een label past.

### Vormen

```js
c.rect(x, y, w, h, opties)          // standaard wit gevuld, grijze rand
c.line(x1, y1, x2, y2, opties)
c.poly([[x,y], ...], opties)
c.path('M ... Q ...', opties)
c.circle(cx, cy, diameter, opties)
c.ellipse(cx, cy, w, h, opties)
```

Opties gaan rechtstreeks naar rough.js: `fill`, `fillStyle` (`'solid'` of `'hachure'`),
`hachureGap`, `fillWeight`, `stroke`, `strokeWidth`, `roughness`, `bowing`,
`strokeLineDash: [12, 10]`, `disableMultiStroke`.

### Pijlen

```js
c.arrow(x1, y1, x2, y2, opties)                  // rechte pijl
c.carrow(x1, y1, cx, cy, x2, y2, opties)         // gebogen pijl, (cx,cy) = controlepunt
```

`opties.head` (standaard 16) regelt de lengte van de pijlpunt. Laat het eindpunt ~20px
voor het label stoppen zodat de punt de tekst niet raakt.

### Samengestelde elementen

```js
c.bubble(cx, top, w, h, label, tx, ty, size = 36)   // opmerkingsballon met streepje naar (tx,ty)
c.cell(x, y, w, h, waarde, opties)                 // rood gearceerd vakje (array-cel)
c.box3d(x, y, w, h, label, {depth = 26, size = 28}) // doosje met perspectief
```

`label` mag een string of een array van regels zijn.

### Opslaan

```js
c.save('naam')                     // -> ./naam.svg en ./naam.png
c.save('naam', { dir: 'out' })     // -> allebei in out/
c.save('naam', { pngDir: '..' })   // -> PNG een map hoger (Quarto-boeklayout)
c.save('naam', { suffix: 'NEW' })  // -> naamNEW.png naast een bestaand origineel
```

Paden zijn relatief aan de **cwd**, dus draai het script vanuit de map waar het staat.
Ontbrekende mappen worden aangemaakt. De Caveat-fonts worden als base64 in de SVG
ingebed, zodat die ook buiten deze map correct opent.

## Eigen helpers

Teken je iets dat terugkomt (een codedoos, een geheugenvakje, een stack/heap-figuur), zet
die helper dan in een apart bestand naast `excal.js` en `require` het erbij:

```js
const { codebox } = require('./mhelpers');
```

In de repo `ziescherpscherper` staan er al een aantal onder
`content/assets/*/imagegen/` (`mhelpers.js` met `codebox`/`monitor`, `vhelpers.js` met
`slot`/`bin`, `arr.js` met stack/heap-regio's). Teken je iets vergelijkbaars, kopieer dan
zo'n helper in plaats van hem opnieuw te schrijven.
