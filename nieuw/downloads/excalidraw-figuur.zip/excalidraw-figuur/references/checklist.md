# Checklist bij het nakijken van de PNG

Open de gerenderde PNG met de Read tool en loop dit af. Bijna elke fout hieronder is al
eens gebeurd. rough.js geeft geen foutmelding bij lelijke output, dus kijken is de enige
manier om het te weten.

## Tekst

- [ ] Geen enkele tekst raakt of kruist een boxrand, een lijn of een pijl.
- [ ] Geen twee teksten die elkaar overlappen.
- [ ] Alle tekst staat binnen het canvas, ook lange labels (die lopen makkelijk over de
      rechterrand; Caveat is smal, dus reken ~0,42 x fontgrootte per teken).
- [ ] Tekst in een box zit verticaal gecentreerd, niet tegen de boven- of onderrand.
- [ ] Font is overal Caveat. Blokletterige tekst betekent dat de render het font niet
      vond: staan `caveat-400.ttf` en `caveat-700.ttf` naast `excal.js`?

## Layout

- [ ] Geen titel bovenaan de figuur. Het bijschrift staat al bij de figuur in de tekst.
- [ ] Onderaan en rechts geen grote lege strook. Pas dan `createCanvas` aan.
- [ ] Elementen die bij elkaar horen staan ook visueel dicht bij elkaar, met duidelijk
      meer ruimte tussen de groepen.
- [ ] Bij twee situaties naast elkaar (voor/na): allebei even breed en op dezelfde
      hoogtes uitgelijnd.

## Pijlen

- [ ] Elke pijl begint aan de rand van zijn vertrekelement, niet er middenin.
- [ ] De pijlpunt stopt kort voor het doel, en overlapt geen tekst.
- [ ] Bij `carrow`: de bocht loopt niet dwars door een ander element. Verleg het
      controlepunt in plaats van het eindpunt.

## Inhoud

- [ ] Alles wat gevraagd was, staat er. Niets stilzwijgend weggelaten.
- [ ] Niets toegevoegd dat niet gevraagd was: geen extra iconen, tekst of versiering.
- [ ] Herteken je een bestaande figuur, dan staat alles uit het origineel er ook.
- [ ] Staat er code in de figuur, dan klopt die en compileert ze in de taal van het
      project. Volg de terminologie van het project.
- [ ] Geen em-dashes in de labels.
