# excalidraw-figuur: zo zet je deze skill naar je hand

Deze skill laat een AI-agent (Claude in VS Code, of Claude Code) figuren tekenen in een handgetekende
stijl: schema's, stappenplannen, posters en kaartjes. Elke figuur komt uit een klein script, zodat je
ze later bijstuurt zonder van nul te beginnen. Tim Dams schreef ze voor de figuren in zijn handboek Zie
Scherp Scherper, en maakte ze daarna geschikt voor elk project.

Dit bestand is voor jou. De AI leest `SKILL.md`.

## Wat erin zit

| Map of bestand | Wat |
|---|---|
| `SKILL.md` | Het recept dat de AI leest: hoe ze een figuur opzet, tekent, nakijkt en oplevert, en de huisstijl. |
| `references/api.md` | De tekenfuncties: tekst, vakjes, pijlen, ballonnen, en hoe een figuur bewaard wordt. |
| `references/checklist.md` | Wat de AI op elke figuur nakijkt voor ze iets oplevert. |
| `assets/excal.js` | De tekenmachine: de kleuren en de functies uit `api.md`. |
| `assets/sjabloon.js` | Een leeg script waar elke nieuwe figuur van vertrekt. |
| `assets/caveat-400.ttf`, `assets/caveat-700.ttf` | Het handschrift Caveat. Zonder die twee wordt de tekst blokletterig. |
| `assets/OFL-caveat.txt` | De licentie van Caveat. Die mag je vrij gebruiken en doorgeven, zolang dit bestand meegaat. |

## Wat je nodig hebt

- Een AI die zelf in een map op je computer werkt: Claude in VS Code, of Claude Code.
- Node.js. De AI installeert het als het ontbreekt, en vraagt je dat eerst.

De eerste keer installeert de AI drie programma's voor het tekenen (`roughjs`, `jsdom` en
`@resvg/resvg-js`). Dat gebeurt één keer per project.

Deze skill tekent uit code. Een potloodtekening of een foto maakt ze niet: die maak je in ChatGPT,
Gemini of Copilot, en de AI zet ze daarna in je figuur.

## Installeren

Pak de zip uit. Je krijgt een map `excalidraw-figuur`.

- **Voor één project**: zet de map in `.claude/skills/` in de map van dat project.
- **Voor al je projecten**: zet de map in de skills-map van Claude op je computer. Op Windows is dat
  `C:\Users\<jouw naam>\.claude\skills\`.

Claude haalt de skill er zelf bij als je om een figuur, een schema of een tekening vraagt.

## Wat je waar aanpast

| Wat | Waar |
|---|---|
| De kleuren van je school | `C` bovenaan `assets/excal.js`, en het stuk *Stijl* in `SKILL.md` |
| Het handschrift | de twee `.ttf`-bestanden in `assets/`, en de naam van het lettertype in `excal.js` |
| Wat de AI eerst vraagt | `SKILL.md`, stuk *Werkwijze* |
| Wat er nooit in een figuur mag | `SKILL.md`, stuk *Inhoudsregels* |
| Een fout die bij jou terugkomt | `references/checklist.md`. Dat is de verbeterlijst van deze skill. |

`SKILL.md` noemt Tim bij naam, en twee van zijn repo's. Laat die gerust staan: de AI leest daar enkel
uit dat ze de figuur eerst moet tonen voor ze die in je tekst zet.

Let op bij een ander handschrift: de AI schat hoe breed een label is op basis van Caveat. Laat na de
wissel een figuur renderen en kijk of er geen tekst over een rand loopt.

## Laat het de AI doen

Je hoeft die bestanden niet zelf te openen. Zeg in de map waar de skill staat:

> Lees de skill excalidraw-figuur en zet ze naar mijn hand. De huisstijl van [naam van je school]:
> [kleuren, bijvoorbeeld donkerblauw #1F3A5F en geel #F2C300], lettertype [naam]. Mijn schrijfregels
> staan in [je regelbestand]. Pas enkel de kleuren, het lettertype en het stuk Stijl aan, en toon me
> eerst wat je wil veranderen.

Laat daarna één figuur tekenen, en loop zelf `references/checklist.md` af.
