---
name: excalidraw-figuur
description: Teken of herteken een figuur, schema, diagram, illustratie of poster in de hand-drawn Excalidraw-stijl (rough.js + Caveat, rood/grijze AP-kleuren), als regenereerbaar Node-script. Gebruik dit bij elke vraag om een figuur, schema of tekening te maken of aan te passen voor een cursus, boek, slide of README, en bij het bijsturen van een bestaand generatorscript in een imagegen-map.
---

# Excalidraw-figuur

Figuren worden niet met de hand getekend maar **gegenereerd met een Node-script** dat rough.js
gebruikt. Elk script blijft bewaard, zodat een figuur later bijgestuurd kan worden zonder van nul te
beginnen: het beeld komt uit code, dus het is regenereerbaar en het zit in versiebeheer.

Dit is de veralgemeende versie van de `afbeelding`-skill uit de repo's `ziescherpscherper` en
`cursusAICursus`. De stijl en de kleuren zijn identiek: dat is bewust, het is dezelfde huisstijl.
Werk je in een van die twee repo's, gebruik dan de skill die daar staat, want die kent de
mappenstructuur van dat project.

## Werkwijze

### 1. Weten wat je tekent

- Tim noemt de figuur meestal zelf. Doet hij dat niet en gaat het over een heel hoofdstuk of een
  hele module: **vraag eerst welke figuur(en)**. Nooit zelf kiezen.
- Pas je een bestaande figuur aan: zoek het origineel op en **bekijk die PNG met de Read tool**. Je
  zet om wat er staat, je verzint niets bij.
- Een goede figuur toont een werkwijze of een verhouding. Geen versiering.

### 2. De imagegen-map klaarzetten

Eenmalig per project. Kies een plek die bij het project past: staat er al een `imagegen/`-map, gebruik
die; anders naast de afbeeldingen die het project al heeft (`assets/`, `content/assets/<deel>/`,
`docs/images/`, `static/`). Vraag het als het niet duidelijk is.

```bash
mkdir -p <pad>/imagegen
cp ~/.claude/skills/excalidraw-figuur/assets/{excal.js,caveat-400.ttf,caveat-700.ttf,package.json} <pad>/imagegen/
```

De fonts moeten mee: zonder die twee wordt alle tekst blokletterig in de PNG.

Dan de dependencies. Bij voorkeur lokaal, en `node_modules/` in `.gitignore`:

```bash
cd <pad>/imagegen && npm install
```

Heeft het project of een zusterrepo de packages al (`roughjs`, `jsdom`, `@resvg/resvg-js`), dan kan je
die hergebruiken in plaats van opnieuw te downloaden:

```bash
export NODE_PATH="/pad/naar/repo/node_modules"
```

`NODE_PATH` wordt gelezen vanaf je huidige map, dus zet die regel voor je naar de imagegen-map gaat.

### 3. Het script schrijven

Start van [assets/sjabloon.js](assets/sjabloon.js). De volledige API staat in
[references/api.md](references/api.md). Kijk eerst of er al een helper bestaat die past, en hergebruik
of kopieer die in plaats van hem opnieuw te schrijven.

Canvas: breedte 900 tot 2300, hoogte in verhouding. Coordinaten zijn absoluut, dus reken posities uit
in plaats van te gokken.

### 4. Renderen

Draai het script vanuit de imagegen-map zelf, want de paden in `c.save` zijn relatief aan de cwd:

```bash
cd <pad>/imagegen && node <naam>.js
```

### 5. Nakijken (niet overslaan)

**Bekijk de gerenderde PNG met de Read tool.** rough.js geeft geen foutmelding bij lelijke output, dus
je moet echt kijken. Loop de checklist in [references/checklist.md](references/checklist.md) af,
corrigeer het script en render opnieuw tot het klopt.

### 6. Opleveren

- **Verwerk de figuur niet in de tekst.** Geen `.qmd`, `.md` of `.tex` aanpassen. Tim bekijkt eerst
  zelf. Vraagt hij er expliciet om, dan mag het wel.
- Stuur de PNG naar Tim met SendUserFile (`display: "render"`) en vermeld het pad.

## Naamgeving

Drie bestanden per figuur, standaard alle drie naast elkaar in de imagegen-map:

| Bestand | Wat |
|---|---|
| `<naam>.js` | het generatorscript, blijft bewaard |
| `<naam>.svg` | tussenresultaat |
| `<naam>.png` | wat in de tekst gebruikt wordt |

Vervang je een bestaande figuur, laat het origineel dan staan tot Tim de nieuwe versie gezien heeft:
`c.save('naam', { suffix: 'NEW' })` geeft `naamNEW.png`. Wil het project de PNG een map hoger (de
Quarto-boeklayout van `ziescherpscherper`), dan `c.save('naam', { pngDir: '..' })`.

## Inhoudsregels (vast)

- **Geen titel boven de figuur.** Het bijschrift staat al bij de figuur in de tekst.
- **Tekst overlapt nooit** met de lijn van een box of met een pijl. Houd labels buiten de pijllijn en
  laat pijlpunten kort voor het label stoppen.
- **Verzin niets extra.** Enkel wat gevraagd is: geen extra elementen, iconen of tekst.
- Taal: Nederlands, en **geen em-dashes** in labels of bijschriften.

## Stijl (niet wijzigen zonder Tim)

- Hand-drawn via rough.js, handgeschreven font Caveat (als base64 ingebed in de SVG).
- Kleuren staan als constanten in `excal.js` (`C.RED`, `C.RED_DARK`, `C.RED_LIGHT`, `C.GRAY`,
  `C.OFFWHITE`). Gebruik geen losse hex-waarden. Heeft het project een eigen huisstijl die hiervan
  afwijkt, vraag dan eerst of die voorgaat.
- `roughness` 1.4 tot 1.6, `bowing` 1 tot 1.5, `strokeWidth` 2 tot 3, `hachure`-vulling voor
  accentvakjes, `solid` voor witte vlakken. De defaults in `excal.js` zitten al goed.

## Posters

Een samenvattende poster is dezelfde machinerie, maar met een andere opdracht: hij vat samen in plaats
van uit te leggen. Twee dingen erbij:

- **bewaar de prompt** naast de poster in de imagegen-map, zodat de poster later bij te sturen is.
- staat er beeld van iemand anders in, dan hoort auteur en licentie in het bijschrift.

## Wanneer niet deze skill

- **Stroomdiagrammen en flowcharts uit tekst**: gebruik `mermaid-pdf`, niet dit.
- **Foto's, illustraties of gegenereerd beeld**: gebruik `imagen` (OpenRouter). Deze skill tekent
  schema's uit code, geen fotorealistisch of geschilderd beeld.
