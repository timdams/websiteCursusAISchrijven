# src/stijl: wat er in de startkit zit

Alle paden relatief aan `src/`. Coördinaten zijn absolute pixels op het canvas (1920x1080 of
1080x1920), tenzij anders vermeld.

## project.ts

`PROJECT` met alles wat per project verschilt: `titel`, `website`, `verteller`, `pixelart`,
`trefwoorden`, `commentaar`. Uitleg per veld in [opzet.md](opzet.md).

## kleuren.ts

`C.RED`, `C.RED_DARK`, `C.RED_LIGHT`, `C.GRAY`, `C.OFFWHITE`, `C.WHITE`, en voor de console
`C.CONSOLE_BG`, `C.CONSOLE_BALK`, `C.CONSOLE_RAND`, `C.CONSOLE_LABEL`, `C.CONSOLE_TEKST`. Geen losse
hex-waarden in een filmpje.

## fonts.ts

- `HAND`: Caveat 400/700.
- `MONO`: JetBrains Mono 400/500/700.
- `SANS`: Inter 400/700, voor het consolelabel en ondertitels.
- `MONO_BREEDTE = 0.6`: elk teken van JetBrains Mono is 0,6 em breed.
- `handBreedte(tekst, grootte)`: geschatte breedte van een tekst in Caveat, aan de ruime kant. Voor een
  onderlijn onder een titel, een woordje centreren boven een pijl, of een lettergrootte die in de
  breedte moet passen.

## anim.ts

| Naam | Wat |
|---|---|
| `IN`, `BEWEEG`, `POP`, `WEG` | easings: binnenkomen, verplaatsen, klein overschot, weggaan |
| `voortgang(f, start, duur, easing = IN)` | 0 tot 1 tussen `start` en `start + duur`, geklemd |
| `venster(f, van, tot, fade = 12)` | 1 tussen `van` en `tot`, met een fade aan beide kanten |
| `getypt(tekst, f, start, framesPerTeken = 2)` | typemachine via slicing |
| `herschrijf(f, start, basis, weg, erbij, framesPerTeken = 3)` | eerst `weg` tekens achteraan wissen, dan `erbij` typen |
| `bezig(f, start, eind)` | handig voor de cursor tijdens het typen |

## ruw.tsx

Vormfuncties geven een `Vorm` terug (`{ drawables, vak }`). Maak ze **op moduleniveau** met een
eigen `seed`, niet in de render.

| Functie | |
|---|---|
| `rechthoek(x, y, w, h, o)` | |
| `lijn(x1, y1, x2, y2, o)` | |
| `pijl(x1, y1, x2, y2, o, kop = 18)` | kop op het eindpunt |
| `cirkel(cx, cy, diameter, o)`, `ellips(cx, cy, w, h, o)` | |
| `veelhoek(punten, o)` | `[[x, y], ...]` |
| `pad(d, vak, o)` | een SVG-pad; het omhullende vak geef je zelf mee |
| `samen(...vormen)` | één vorm uit meerdere, samen onthullen of verplaatsen |

`o` zijn rough.js-opties. Standaard: grijze lijn 2,2 px, roughness 1.5, bowing 1, seed 7. Veel gebruikt:
`{ fill: C.WHITE, fillStyle: "solid" }` voor een vlak, `{ fill: C.RED_LIGHT, fillStyle: "hachure",
hachureGap: 9, fillWeight: 2, stroke: C.RED }` voor een accent, `{ stroke: "none" }` voor een
markeerstift.

`<Ruw vorm toon richting streep opacity schaal />` tekent de vorm.

- `toon` (0 tot 1) onthult de vorm via een clip, in `richting` `vanLinks`, `vanRechts`, `vanOnder` of
  `vanBoven`. Zo tekent een lijn of pijl zichzelf.
- `streep` is een `strokeDasharray` (`"12 12"` voor een stippellijn).
- `schaal` schaalt rond het midden van de vorm.

## op.tsx

`<Op x y hoek schaal opacity>`: zet inhoud met lokale coördinaten rond (0, 0) op een plek, eventueel
gedraaid of geschaald. Voor een wiel dat draait, een kaartje dat vliegt, een brokstuk.

## tekst.tsx

- `<Opmaak tekst grootte nadruk />`: `` `code` `` in mono op lichtroze, `*nadruk*` in de nadrukkleur.
- `<Onderschrift regels van tot midden = 972 grootte = 60 kleur = C.RED_DARK />`: het onderschrift van
  een kennisclip, gecentreerd rond `midden`, met fade.
- `<Noot tekst x y opacity grootte = 50 />`: een handgeschreven woordje naast een pijl. `y` is het
  verticale midden.

## verteller.tsx

`<Verteller x y hoogte opacity />`: de afbeelding uit `PROJECT.verteller`. Toont niets als er geen
verteller is.

## Voor code

Enkel nodig als de bron over code gaat. Zonder code blijven deze bestanden gewoon ongebruikt staan.

### code.tsx

- `Raster = { x, y, grootte, hoogte }`: linkerbovenhoek van rij 0, kolom 0, lettergrootte en rijhoogte.
- `tekenBreedte(r)`, `kolomX(r, kolom)`, `rijY(r, rij)`: de exacte plaats van een teken. Markeringen,
  knip-lijnen en pijlen mikken hierop.
- `Regel = { tekst, rij, dx?, dy?, opacity?, cursor?, kleur? }`.
- `<Regels raster regels kleur gewicht keywords />`. Met `keywords` staan de `trefwoorden` uit
  `project.ts` vet; regels die (eventueel ingesprongen) met het `commentaar`-teken beginnen, blijven
  onaangeroerd.

### panelen.tsx

`<ConsolePaneel vak label="Console" />`: het zwarte consolevenster, met een label naar keuze
("Terminal", "Uitvoer"). `CONSOLE_BALK = 60` is de hoogte van het labelbalkje; de uitvoer begint
daaronder.

### werkblad.tsx (liggend)

- `CODE_VAK`, `CONSOLE_VAK`: de twee panelen. `CODE`, `UIT`: de rasters voor code en uitvoer.
- `<Werkblad code uitvoer onderCode bovenCode bovenUitvoer uitvoerOpacity binnen consoleLabel />`:
  code links, console rechts. `onderCode` ligt onder de codetekst (markeerstift), `bovenCode` en
  `bovenUitvoer` erboven (knip-lijnen, arcering, pijlen). `binnen` (0 tot 1) laat het werkblad
  binnenschuiven.
- `markeer(rij, kol, n, seed)`: markeerstift achter `n` tekens code.
- `codeStrook(vanRij, rijen, kolommen, seed)`, `uitvoerStrook(...)`: gearceerde strook over de eerste
  kolommen, bv. om inspringing aan te wijzen.
- `knip(kol, vanRij, totRij, seed)`: verticale knip-lijn links van een kolom.

## reel.tsx (staand)

- `REEL_VERTELLER`, `REEL_BALLON`: vaste plaats van de verteller en zijn ballon. Zonder verteller loopt
  de ballon over de hele breedte.
- `type ReelTekst = { van, tot, regels }`.
- `<VertellerBallon teksten van tot />`: de ballon, met de verteller ernaast als die er is. De regels
  van een tekst komen kort na elkaar binnen en de verteller wiebelt een beetje.
- `<Haak boven groot onder tot top seed ovaalBreedte = 640 ovaalHoogte = 350 onderAfstand = 375 />`:
  het eerste beeld. Drie smalle cijfers van 340 px passen in 640x350; een breder getal ("125") vraagt
  720x380 en `onderAfstand` 400.
- `<EindKaart start onderdeel bron />`: verteller (als die er is), titel en website uit `project.ts`,
  het onderdeel (hoofdstuk, module, les; leeg laten om het weg te laten) en de bron in klein. Een
  lange titel krimpt vanzelf.
