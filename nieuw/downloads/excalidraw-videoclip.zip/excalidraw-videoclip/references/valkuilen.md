# Valkuilen

Elk probleem hieronder is echt voorgekomen bij de eerste kennisclip en de eerste reels. Geen enkel
ervan gaf een foutmelding: ze vielen pas op bij het bekijken van een still.

## Tekenen

| Wat je zag | Oorzaak | Oplossing |
|---|---|---|
| Alle vormen trillen bij het afspelen | rough.js krabbelt zonder vaste seed elk frame opnieuw | elke vorm een eigen `seed`, vormen op moduleniveau aanmaken |
| Een lijn loopt zichtbaar door een gearceerde vorm (een kabel door een locomotief) | `hachure` is doorzichtig tussen de streepjes | eerst dezelfde vorm wit en `solid` zonder rand eronder leggen |
| Een knip-lijn raakt de tekens | de ruwe uitwijking van rough.js | de lijn 8 px voor de kolom zetten (`knip` doet dat) |
| Een onderlijn raakt de voet van een teken | lijn op de basislijn | onder het teken: bij een rijhoogte van 56 op `rijY + 55` |
| De ovaal raakt het grote getal | te krap berekend | 640x350 voor drie smalle cijfers, 720x380 voor "125"; altijd op een still nakijken |
| Een ruimtesonde van 50 px is op een gsm een stipje | op het scherm van de pc lijkt het groot genoeg | minstens 150 px breed; een explosie ook groter (200 px) en trager (70 frames) |
| `=` tussen twee rijen oogt piepklein | leestekens in Caveat zijn kleiner dan letters | leestekens een maat groter zetten |

## Tekst

| Wat je zag | Oorzaak | Oplossing |
|---|---|---|
| Aanhalingstekens in een onderschrift worden een rij schuine streepjes | Caveat tekent aanhalingstekens schuin | code en letterlijke tekst tussen backticks: `Opmaak` zet ze in mono |
| Een etiket viel weg terwijl de ballon er nog over sprak | de animatie liep voor op de tekst | wat de ballon noemt, blijft in beeld tot de ballon wisselt |
| Het laatste onderschrift van een scène verdwijnt voor de overgang | `tot` gelijk aan de scèneduur, en de fade begint vroeger | `tot={S_DUUR + 20}` voor het laatste onderschrift |
| Tekst valt onder de naam of de knoppen van Instagram | buiten de veilige zone | bovenaan 250 px en onderaan 420 px vrij laten |

## Timing

| Wat je zag | Oorzaak | Oplossing |
|---|---|---|
| Een trein schokt | interpoleren over het aantal wagons of assen in plaats van over de afstand | de afgelegde afstand interpoleren, al de rest daaruit afleiden |
| Een teller loopt uit de pas met wat hij telt | twee aparte timers | één positie per frame; de teller telt wat die positie gepasseerd is |
| Wielen glijden in plaats van te rollen | een vaste draaisnelheid | hoek = afgelegde weg gedeeld door de straal |
| Iets tellen tot 256 duurt veel te lang | echte snelheid | vooruitspoelen met een getekend vooruitspoelteken, pauzeren terwijl de ballon uitlegt |
| De haak is op frame 0 leeg | de tekst faadt in | tekst staat er vanaf frame 0, enkel de ovaal of versiering animeert |
| Een reel van 63 s | te veel ballonnen | `FASE.eind` hoogstens 1800 (60 s); een story knipt anders |

## Code en project

| Wat je zag | Oorzaak | Oplossing |
|---|---|---|
| TypeScript-fout op `.includes()` of `.trimStart()` | de `tsconfig` van Remotion kent enkel `es2015` | `indexOf(...) >= 0`, `replace(/^\s+/, "")` |
| Elke render ziet er anders uit | `Math.random()` | vaste data, `random(seed)` uit remotion, of een eigen generator met seed |
| Een beweging rendert niet in de mp4 | CSS-animatie of -transition | enkel `useCurrentFrame()` en `interpolate()` |
| Getallen op het scherm klopten niet met de echte uitvoer | zelf bedacht | de code eerst draaien in de taal van de bron |
| Stills renderen duurt lang | elke still bundelt het project opnieuw | een reeks in één PowerShell-lus; het volledige filmpje op de achtergrond |
