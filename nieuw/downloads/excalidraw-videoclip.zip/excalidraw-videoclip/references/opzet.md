# Een nieuw Remotion-project opzetten

`<skill>` is de map van deze skill (de basismap die vermeld wordt als de skill laadt). De commando's
zijn voor PowerShell; de paden zijn relatief aan de root van het project waar de filmpjes bij horen.

## 0. Nodig

- Node.js.
- Internet tijdens het renderen: de fonts komen van Google Fonts.
- De skill `remotion-best-practices`. Ontbreekt die: `npx skills add remotion-dev/skills`.

## 1. Plaats kiezen

Vraag de gebruiker waar. Kies een map die de site of het boek niet publiceert: bij Quarto een naam die met een
underscore begint (bv. `_kennisclips/`, die slaat Quarto over), bij andere generators een map buiten
de bronmap. Zonder site mag het gewoon `video/` zijn.

## 2. Het sjabloon van Remotion

In de root van het project (dit maakt de map aan):

```powershell
npx --yes create-video@latest --yes --blank --no-tailwind _kennisclips
```

## 3. Opkuisen

Het blanco sjabloon bracht in versie 4.0.524 ondanks `--no-tailwind` toch Tailwind en voorbeeldcode
mee. Kijk wat jouw versie meebrengt en haal weg:

- `@remotion/tailwind-v4` en `tailwindcss` (`npm uninstall @remotion/tailwind-v4 tailwindcss` na
  stap 4);
- `src/index.css`, `src/Composition.tsx` en, als die er is, `src/basic-captions.element.tsx`;
- `remotion.config.ts`: vervang door `<skill>/assets/remotion.config.ts` (zonder Tailwind).

`src/index.ts` (met `registerRoot(RemotionRoot)`) blijft staan.

## 4. Pakketten

In de nieuwe map:

```powershell
npm i
npx remotion add @remotion/google-fonts @remotion/transitions
npm i roughjs
```

`remotion add` neemt dezelfde versie als `remotion` zelf. Pakketten van verschillende
Remotion-versies door elkaar geven vreemde fouten.

## 5. De startkit kopiëren

Vanuit de map van het Remotion-project, zolang `src/stijl/` nog niet bestaat:

```powershell
Copy-Item -Recurse <skill>/assets/stijl src/stijl
Copy-Item -Force <skill>/assets/Root.tsx src/Root.tsx
New-Item -ItemType Directory -Force src/clips, src/reels | Out-Null
Copy-Item -Recurse <skill>/assets/sjabloon-kennisclip src/clips/voorbeeld
Copy-Item -Recurse <skill>/assets/sjabloon-reel src/reels/voorbeeld
```

## 6. project.ts invullen

Samen met de gebruiker, in `src/stijl/project.ts`:

| Veld | Wat |
|---|---|
| `titel` | naam van het project (boek, cursus, reeks), op de eindkaart en de afsluiter |
| `website` | op de eindkaart; leeg laten om ze weg te laten |
| `verteller` | bestandsnaam van de vertellerfiguur in `public/`, of `null` voor reels zonder verteller |
| `pixelart` | `true` als de verteller pixelart is (vergroten zonder vervaging) |
| `trefwoorden` | woorden die in code vet staan (types of sleutelwoorden van de taal); leeg zonder code |
| `commentaar` | teken waarmee een commentaarregel begint (`//`, `#`, `--`) |

Een verteller van een andere verhouding dan 3 op 4: stel `REEL_VERTELLER` en de staart van de ballon
bij in `src/stijl/reel.tsx`.

## 7. .gitignore

`node_modules` en `out` moeten erin staan. Het sjabloon zet ze er meestal al in; kijk na.

## 8. Controle

```powershell
npx tsc --noEmit
npx remotion still Voorbeeld-kennisclip out/test-schema.png --frame=220 --scale=0.5
npx remotion still Voorbeeld-kennisclip out/test-werkblad.png --frame=400 --scale=0.5
npx remotion still Voorbeeld-reel out/test-reel.png --frame=250 --scale=0.5
```

Bekijk de png's met de Read tool. Staat de tekst in handschrift (Caveat), de code in JetBrains Mono
en hebben de vlakken een ruwe rand, dan werkt alles. Blokletters in plaats van handschrift: de fonts
konden niet laden (geen internet tijdens de render?).

De `tsconfig.json` van Remotion kent enkel `es2015`: geen `Array.includes`, `Object.values`,
`padStart` of `trimStart`. De startkit houdt zich daaraan.

## 9. Render-scripts

Per filmpje een script in `package.json`:

```json
"render:<naam>": "remotion render <id> out/<naam>.mp4"
```

De twee voorbeelden in `Root.tsx` en de mappen `voorbeeld` mogen weg zodra er een echt filmpje is.
