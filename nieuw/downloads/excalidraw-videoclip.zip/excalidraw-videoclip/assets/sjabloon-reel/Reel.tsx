import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { POP, bezig, getypt, venster, voortgang } from "../../stijl/anim";
import { Regels, type Raster, type Regel } from "../../stijl/code";
import { MONO } from "../../stijl/fonts";
import { C } from "../../stijl/kleuren";
import { ConsolePaneel } from "../../stijl/panelen";
import { EindKaart, Haak, VertellerBallon } from "../../stijl/reel";
import { Ruw, rechthoek } from "../../stijl/ruw";
import { FASE, TEKSTEN } from "./tijdlijn";

export { DUUR } from "./tijdlijn";

// Sjabloon voor een reel: haak, verteller met ballon, een tekening, een brugscène en de eindkaart.
// Vervang de tekening en de brug; de ballonteksten staan in tijdlijn.ts. Tekenen tussen y 600 en 1480.

const DOOS = rechthoek(290, 760, 500, 380, {
  fill: C.RED_LIGHT,
  fillStyle: "hachure",
  hachureGap: 10,
  fillWeight: 2,
  stroke: C.RED,
  strokeWidth: 3,
  seed: 2000,
});

const Tekening: React.FC = () => {
  const f = useCurrentFrame();
  const zicht = venster(f, FASE.verhaal, FASE.brug, 15);
  if (zicht <= 0) return null;
  const pop = voortgang(f, FASE.verhaal + 10, 20, POP);
  return (
    <AbsoluteFill style={{ opacity: zicht, transform: `scale(${0.8 + 0.2 * pop})`, transformOrigin: "540px 950px" }}>
      <Ruw vorm={DOOS} toon={voortgang(f, FASE.verhaal + 10, 30)} richting="vanBoven" />
    </AbsoluteFill>
  );
};

// De brug koppelt het verhaal aan de kern van de bron. Hier een regel code met zijn uitvoer, in de
// taal van de bron en eerst gedraaid. Zonder code: een kernzin in Caveat of een tweede tekening.
const PANEEL = rechthoek(80, 640, 920, 200, { fill: C.WHITE, fillStyle: "solid", strokeWidth: 2.4, seed: 2010 });
const RASTER: Raster = { x: 124, y: 705, grootte: 44, hoogte: 70 };
const CODE = "print(256)";
const UITVOER = "256";

const Brug: React.FC = () => {
  const f = useCurrentFrame();
  const zicht = venster(f, FASE.brug, FASE.einde, 15);
  if (zicht <= 0) return null;
  const s = FASE.brug;
  const regels: Regel[] = [{ rij: 0, tekst: getypt(CODE, f, s + 10, 1.2), cursor: bezig(f, s + 10, s + 40) }];

  return (
    <AbsoluteFill style={{ opacity: zicht }}>
      <Ruw vorm={PANEEL} />
      <Regels raster={RASTER} regels={regels} kleur={C.GRAY} keywords />
      <ConsolePaneel vak={{ x: 80, y: 880, w: 920, h: 230 }} />
      <div
        style={{
          position: "absolute",
          left: 124,
          top: 980,
          fontFamily: MONO,
          fontSize: 64,
          fontWeight: 500,
          lineHeight: 1,
          color: C.CONSOLE_TEKST,
          opacity: voortgang(f, s + 50, 8),
        }}
      >
        {UITVOER}
      </div>
    </AbsoluteFill>
  );
};

export const Reel: React.FC = () => (
  <AbsoluteFill style={{ backgroundColor: C.OFFWHITE }}>
    <Haak boven={["Een zin met"]} groot="256" onder={["een getal als haak."]} tot={FASE.verhaal} seed={2020} />
    <Tekening />
    <Brug />
    <VertellerBallon teksten={TEKSTEN} van={FASE.verhaal} tot={FASE.einde} />
    <EindKaart start={FASE.einde} onderdeel="hoofdstuk 1" bron={["Bron: ..."]} />
  </AbsoluteFill>
);
