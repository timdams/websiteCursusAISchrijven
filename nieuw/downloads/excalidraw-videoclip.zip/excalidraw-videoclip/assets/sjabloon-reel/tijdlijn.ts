import type { ReelTekst } from "../../stijl/reel";

// Eén tijdlijn voor de hele reel: het startframe van elk deel. Elk onderdeel toont zich met
// venster(f, FASE.a, FASE.b), zodat een beeld kan doorlopen over de delen heen.
export const FASE = {
  verhaal: 120,
  brug: 540,
  einde: 840,
  eind: 960,
};
// Hoogstens 1800 frames (60 s): een Instagram-story knipt daar.
export const DUUR = FASE.eind;

// De tekst in de ballon komt uit de bron, hoogstens ingekort of over ballonnen verdeeld.
export const TEKSTEN: ReelTekst[] = [
  { van: FASE.verhaal, tot: 330, regels: ["Hier vertelt de verteller", "het verhaal uit de *bron*."] },
  { van: 330, tot: FASE.brug, regels: ["Hoogstens vier regels", "per ballon."] },
  { van: FASE.brug, tot: FASE.einde, regels: ["En dan de brug naar", "de *kern* van de bron."] },
];
