import { Composition, Folder } from "remotion";
import { DUUR as KENNISCLIP_DUUR, Kennisclip } from "./clips/voorbeeld/Kennisclip";
import { DUUR as REEL_DUUR, Reel } from "./reels/voorbeeld/Reel";

// Kopieer naar src/Root.tsx. Registreer elk nieuw filmpje hier: kennisclips in een Folder per
// onderdeel (hoofdstuk, module), reels in "Reels". De twee voorbeelden mogen weg zodra er een echt
// filmpje is.
const LIGGEND = { fps: 30, width: 1920, height: 1080 };
const STAAND = { fps: 30, width: 1080, height: 1920 };

export const RemotionRoot: React.FC = () => (
  <>
    <Folder name="Kennisclips">
      <Composition id="Voorbeeld-kennisclip" component={Kennisclip} durationInFrames={KENNISCLIP_DUUR} {...LIGGEND} />
    </Folder>
    <Folder name="Reels">
      <Composition id="Voorbeeld-reel" component={Reel} durationInFrames={REEL_DUUR} {...STAAND} />
    </Folder>
  </>
);
