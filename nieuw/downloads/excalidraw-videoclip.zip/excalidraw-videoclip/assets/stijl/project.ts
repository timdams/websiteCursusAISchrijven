// Alles wat per project verschilt. Vul dit in bij de opzet van een nieuw project.
export const PROJECT: {
  titel: string;
  website: string;
  verteller: string | null;
  pixelart: boolean;
  trefwoorden: string[];
  commentaar: string;
} = {
  // Naam van het project (boek, cursus, reeks), op de eindkaart van een reel en de afsluiter van een
  // kennisclip.
  titel: "NAAM VAN HET PROJECT",
  // Website op de eindkaart. Laat leeg om ze weg te laten.
  website: "",
  // Afbeelding van de verteller in public/, bv. "verteller.png". null: reels zonder verteller.
  verteller: null,
  // true als de verteller pixelart is: dan vergroot hij zonder vervaging.
  pixelart: false,
  // Woorden die in code vet staan: de types of sleutelwoorden van de taal. Leeg: niets vet.
  //   C#:         ["string", "int", "double", "bool", "var"]
  //   Python:     ["def", "return", "import", "class"]
  //   JavaScript: ["const", "let", "function", "return"]
  trefwoorden: [],
  // Waarmee een commentaarregel begint: "//" (C#, Java, JavaScript), "#" (Python, PowerShell), "--" (SQL).
  commentaar: "//",
};
