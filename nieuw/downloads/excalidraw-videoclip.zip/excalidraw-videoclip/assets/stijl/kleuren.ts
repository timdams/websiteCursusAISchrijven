// De huisstijl: dezelfde kleuren als de Excalidraw-figuren (skill excalidraw-figuur), met rood als
// accent, en voor code een console als zwart venster met groene tekst.
// Heeft het project een eigen huisstijl, vraag dan eerst of die voorgaat.
export const C = {
  RED: "#FF0000",
  RED_DARK: "#B30000",
  RED_LIGHT: "#FFE5E5",
  GRAY: "#4D4D4D",
  OFFWHITE: "#f8f9fa",
  WHITE: "#ffffff",
  CONSOLE_BG: "#0d1117",
  CONSOLE_BALK: "#161b22",
  CONSOLE_RAND: "#30363d",
  CONSOLE_LABEL: "#c9d1d9",
  CONSOLE_TEKST: "#4ade80",
} as const;
