import React from "react";
import { AbsoluteFill } from "remotion";
import { TransitionSeries, linearTiming } from "@remotion/transitions";
import { fade } from "@remotion/transitions/fade";
import { C } from "../../stijl/kleuren";
import { AFSLUITER_DUUR, Afsluiter } from "./Afsluiter";
import { S1_DUUR, S1Schema } from "./S1Schema";
import { S2_DUUR, S2Werkblad } from "./S2Werkblad";
import { TITEL_DUUR, Titel } from "./Titel";

// Sjabloon voor een kennisclip: titelkaart, scènes, afsluiter. Maak per scène een bestand met zijn
// duur bovenaan, zet het in DUREN en tussen twee overgangen hieronder. S1Schema is een scène zonder
// code, S2Werkblad een met code: hou wat past.
const OVERGANG = 15;
const DUREN = [TITEL_DUUR, S1_DUUR, S2_DUUR, AFSLUITER_DUUR];

export const DUUR = DUREN.reduce((som, d) => som + d, 0) - OVERGANG * (DUREN.length - 1);

const timing = linearTiming({ durationInFrames: OVERGANG });

export const Kennisclip: React.FC = () => (
  <AbsoluteFill style={{ backgroundColor: C.OFFWHITE }}>
    <TransitionSeries>
      <TransitionSeries.Sequence durationInFrames={TITEL_DUUR}>
        <Titel />
      </TransitionSeries.Sequence>
      <TransitionSeries.Transition presentation={fade()} timing={timing} />
      <TransitionSeries.Sequence durationInFrames={S1_DUUR}>
        <S1Schema />
      </TransitionSeries.Sequence>
      <TransitionSeries.Transition presentation={fade()} timing={timing} />
      <TransitionSeries.Sequence durationInFrames={S2_DUUR}>
        <S2Werkblad />
      </TransitionSeries.Sequence>
      <TransitionSeries.Transition presentation={fade()} timing={timing} />
      <TransitionSeries.Sequence durationInFrames={AFSLUITER_DUUR}>
        <Afsluiter />
      </TransitionSeries.Sequence>
    </TransitionSeries>
  </AbsoluteFill>
);
