import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { POP, voortgang } from "../../stijl/anim";
import { HAND, handBreedte } from "../../stijl/fonts";
import { C } from "../../stijl/kleuren";
import { Ruw, lijn } from "../../stijl/ruw";

// Titelkaart: het onderwerp groot in Caveat met een rode onderlijn, eronder één feit.
export const TITEL_DUUR = 90;
const ONDERWERP = "Onderwerp van de clip";
const FEIT = "één feit over het onderwerp";

// De onderlijn is iets korter dan de titel.
const BREEDTE = Math.min(1600, handBreedte(ONDERWERP, 170) * 0.9);
const ONDERLIJN = lijn(960 - BREEDTE / 2, 612, 960 + BREEDTE / 2, 604, {
  stroke: C.RED,
  strokeWidth: 5,
  roughness: 1.3,
  seed: 1,
});

export const Titel: React.FC = () => {
  const f = useCurrentFrame();
  const pop = voortgang(f, 0, 26, POP);
  return (
    <AbsoluteFill>
      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          top: 350,
          textAlign: "center",
          fontFamily: HAND,
          fontSize: 170,
          fontWeight: 700,
          lineHeight: 1,
          color: C.GRAY,
          opacity: voortgang(f, 0, 12),
          transform: `scale(${0.85 + 0.15 * pop})`,
        }}
      >
        {ONDERWERP}
      </div>
      <Ruw vorm={ONDERLIJN} toon={voortgang(f, 22, 26)} />
      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          top: 650,
          textAlign: "center",
          fontFamily: HAND,
          fontSize: 66,
          fontWeight: 700,
          color: C.RED_DARK,
          opacity: voortgang(f, 42, 16),
        }}
      >
        {FEIT}
      </div>
    </AbsoluteFill>
  );
};
