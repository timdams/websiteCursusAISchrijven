import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { bezig, getypt, voortgang } from "../../stijl/anim";
import type { Regel } from "../../stijl/code";
import { Ruw } from "../../stijl/ruw";
import { Onderschrift } from "../../stijl/tekst";
import { Werkblad, markeer } from "../../stijl/werkblad";

// Voorbeeldscène met code: een regel code typt zich, de console toont de uitvoer, een markeerstift
// wijst aan wat op het scherm komt. Vervang de code door code in de taal van de bron (eerst gedraaid),
// en de uitvoer en het onderschrift. Gaat de bron niet over code, laat deze scène dan weg.
export const S2_DUUR = 240;

const CODE_REGEL = 'print("Hallo!")';
const UITVOER = "Hallo!";
// "print(" is 6 tekens, dus de string begint op kolom 6 en is 8 tekens lang.
const MARKERING = markeer(0, 6, 8, 2001);

export const S2Werkblad: React.FC = () => {
  const f = useCurrentFrame();
  const code: Regel[] = [{ rij: 0, tekst: getypt(CODE_REGEL, f, 20, 1.5), cursor: bezig(f, 20, 70) }];
  const uitvoer: Regel[] = [{ rij: 0, tekst: UITVOER, opacity: voortgang(f, 80, 8) }];

  return (
    <AbsoluteFill>
      <Werkblad
        binnen={voortgang(f, 0, 20)}
        code={code}
        uitvoer={uitvoer}
        onderCode={<Ruw vorm={MARKERING} toon={voortgang(f, 110, 14)} />}
      />
      <Onderschrift van={30} tot={S2_DUUR + 20} regels={["Een regel code, en wat ze op het scherm zet"]} />
    </AbsoluteFill>
  );
};
