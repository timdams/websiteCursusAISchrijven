import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { voortgang } from "../../stijl/anim";
import { HAND, handBreedte } from "../../stijl/fonts";
import { C } from "../../stijl/kleuren";
import { PROJECT } from "../../stijl/project";
import { Ruw, lijn } from "../../stijl/ruw";

// Afsluiter: de titel van het project en het onderdeel, met een rode onderlijn.
export const AFSLUITER_DUUR = 150;
// Hoofdstuk, module of les zoals de kijker het kent. Leeg: enkel de titel.
const ONDERDEEL: string = "hoofdstuk 1";
const TEKST = ONDERDEEL === "" ? PROJECT.titel : `${PROJECT.titel}, ${ONDERDEEL}`;

const BREEDTE = Math.min(1600, handBreedte(TEKST, 84) * 0.9);
const ONDERLIJN = lijn(960 - BREEDTE / 2, 600, 960 + BREEDTE / 2, 594, {
  stroke: C.RED,
  strokeWidth: 4,
  roughness: 1.3,
  seed: 2,
});

export const Afsluiter: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{ opacity: voortgang(f, 0, 15) }}>
      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          top: 470,
          textAlign: "center",
          fontFamily: HAND,
          fontSize: 84,
          fontWeight: 700,
          lineHeight: 1,
          color: C.GRAY,
        }}
      >
        {TEKST}
      </div>
      <Ruw vorm={ONDERLIJN} toon={voortgang(f, 20, 25)} />
    </AbsoluteFill>
  );
};
