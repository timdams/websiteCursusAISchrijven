import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { voortgang } from "../../stijl/anim";
import { HAND, handBreedte } from "../../stijl/fonts";
import { C } from "../../stijl/kleuren";
import { Ruw, pijl, rechthoek, type Vak } from "../../stijl/ruw";
import { Noot, Onderschrift } from "../../stijl/tekst";

// Voorbeeldscène zonder code: twee vlakken, een pijl die zichzelf tekent en een woordje erbij.
// Vervang de vlakken, de woorden en het onderschrift. Tekenen tussen y 150 en 870, daaronder staat
// het onderschrift.
export const S1_DUUR = 210;

const LINKS = rechthoek(250, 340, 540, 280, { fill: C.WHITE, fillStyle: "solid", strokeWidth: 2.6, seed: 1001 });
const RECHTS = rechthoek(1130, 340, 540, 280, {
  fill: C.WHITE,
  fillStyle: "solid",
  stroke: C.RED,
  strokeWidth: 3.5,
  seed: 1002,
});
// De pijl stopt 40 px voor elk vlak, zodat hij met de ruwe uitwijking de randen niet raakt.
const PIJL = pijl(830, 480, 1090, 480, { strokeWidth: 3.5, seed: 1003 }, 26);
const NOOT = "wordt";

const woord = (vak: Vak, kleur: string, opacity: number): React.CSSProperties => ({
  position: "absolute",
  left: vak.x,
  top: vak.y,
  width: vak.w,
  height: vak.h,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  fontFamily: HAND,
  fontSize: 96,
  fontWeight: 700,
  color: kleur,
  opacity,
});

export const S1Schema: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Ruw vorm={LINKS} toon={voortgang(f, 0, 22)} richting="vanBoven" />
      <div style={woord(LINKS.vak, C.GRAY, voortgang(f, 14, 12))}>tekst</div>
      <Ruw vorm={PIJL} toon={voortgang(f, 45, 24)} />
      <Noot tekst={NOOT} x={960 - handBreedte(NOOT, 50) / 2} y={410} opacity={voortgang(f, 70, 12)} />
      <Ruw vorm={RECHTS} toon={voortgang(f, 85, 22)} richting="vanBoven" />
      <div style={woord(RECHTS.vak, C.RED, voortgang(f, 99, 12))}>filmpje</div>
      <Onderschrift van={30} tot={S1_DUUR + 20} regels={["Een schema: twee vlakken, een pijl en een *woordje*"]} />
    </AbsoluteFill>
  );
};
