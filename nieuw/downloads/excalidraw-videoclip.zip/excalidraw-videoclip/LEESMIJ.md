# excalidraw-videoclip: zo zet je deze skill naar je hand

Deze skill laat een AI-agent (Claude in VS Code, of Claude Code) geanimeerde filmpjes maken in een
handgetekende stijl: liggende kennisclips die iets uitleggen, en staande reels voor Instagram. Tim
Dams schreef ze voor de filmpjes bij zijn handboek Zie Scherp Scherper, en maakte ze daarna geschikt
voor elk project.

Dit bestand is voor jou. De AI leest `SKILL.md`.

## Wat erin zit

| Map of bestand | Wat |
|---|---|
| `SKILL.md` | Het recept dat de AI leest: wat ze eerst vraagt, de twee soorten filmpjes, hoe ze bouwt en nakijkt, en de huisstijl. |
| `references/opzet.md` | Hoe de AI een nieuw filmpjesproject (Remotion) opzet. |
| `references/stijl.md` | Wat er in de startkit zit: kleuren, lettertypes, animaties, tekenfuncties. |
| `references/valkuilen.md` | Elk probleem dat al eens opdook, met de oplossing. |
| `references/checklist.md` | Wat de AI op elk beeld nakijkt voor ze iets oplevert. |
| `assets/` | De startkit: de code waarmee de AI een nieuw project opzet. |

## Wat je nodig hebt

- Een AI die zelf in een map op je computer werkt: Claude in VS Code, of Claude Code.
- Node.js. De AI installeert het als het ontbreekt, en vraagt je dat eerst.
- Internet tijdens het renderen: de lettertypes komen van Google Fonts.
- De skill `remotion-best-practices`, waar deze skill op steunt. De AI installeert ze met
  `npx skills add remotion-dev/skills` (zie skills.sh).

De eerste keer installeert de AI een reeks programma's. Dat gebeurt één keer.

## Installeren

Pak de zip uit. Je krijgt een map `excalidraw-videoclip`.

- **Voor één project**: zet de map in `.claude/skills/` in de map van dat project.
- **Voor al je projecten**: zet de map in de skills-map van Claude op je computer. Op Windows is dat
  `C:\Users\<jouw naam>\.claude\skills\`.

Claude haalt de skill er zelf bij als je om een filmpje, een kennisclip of een reel vraagt.

## Wat je waar aanpast

| Wat | Waar |
|---|---|
| De kleuren van je school | `assets/stijl/kleuren.ts`, en het stuk *Huisstijl* onderaan `SKILL.md` |
| Het lettertype | `assets/stijl/fonts.ts`. Elk lettertype van Google Fonts kan. |
| De naam van je vak of reeks, je website, een verteller | `src/stijl/project.ts` in je filmpjesproject. De AI vult het samen met jou in bij de opzet. |
| Wat de AI eerst vraagt, en hoe lang een filmpje mag duren | `SKILL.md`, stuk 1 en de tabel eronder |
| Je eigen schrijfregels voor tekst in beeld | Die staan in je eigen regelbestand. `SKILL.md` zegt al dat de AI ze volgt. |
| Een fout die bij jou terugkomt | `references/valkuilen.md`, met de oplossing erbij. Dat is de verbeterlijst van deze skill. |

Let op bij een ander handschrift: de functie `handBreedte` in `fonts.ts` schat de breedte van
handgeschreven tekst, en is afgesteld op Caveat. Laat de AI na de wissel een beeld renderen en
nakijken of onderlijnen en titels nog passen.

## Laat het de AI doen

Je hoeft die bestanden niet zelf te openen. Zeg in de map waar de skill staat:

> Lees de skill excalidraw-videoclip en zet ze naar mijn hand. De huisstijl van [naam van je school]:
> [kleuren, bijvoorbeeld donkerblauw #1F3A5F en geel #F2C300], lettertype [naam]. Mijn schrijfregels
> staan in [je regelbestand]. Pas enkel de kleuren, het lettertype en het stuk Huisstijl aan, en toon
> me eerst wat je wil veranderen.

Kijk daarna een testbeeld na, zoals in `references/opzet.md`, stap 8.
