---
name: excalidraw-videoclip
description: Maak een geanimeerd filmpje met Remotion in de hand-drawn huisstijl van excalidraw-figuur (rough.js, Caveat, een rood accent), voor elk project (cursus, boek, presentatie, blog), met of zonder code. Twee soorten clips. Een kennisclip is liggend en legt iets uit. Een reel is kort, staand, voor Instagram, en vertelt een verhaal of weetje. Er zit een startkit bij om een nieuw Remotion-project op te zetten. Vraagt altijd eerst welk soort clip, en of er een stem, ondertitels en een bijschrift bij moeten. Gebruik dit bij elke vraag om een kennisclip, uitlegfilmpje, filmpje, video, animatie, reel of Instagram-story te maken of aan te passen, of om daarvoor een Remotion-project op te zetten.
---

# Videoclip in Excalidraw-stijl (Remotion)

Een filmpje wordt niet gemonteerd maar geprogrammeerd: elke scène is React-code die Remotion frame
per frame rendert. Alles blijft bewaard, dus een filmpje is later bij te sturen zonder van nul te
beginnen.

Deze skill groeide uit de kennisclips en reels bij het handboek Zie Scherp Scherper van Tim Dams,
waar de eerste kennisclip en drie reels mee gemaakt zijn. De werkwijze is dezelfde, de huisstijl is die van
`excalidraw-figuur`. Heeft het repo waarin je werkt een eigen videoclip-skill, gebruik dan die: die
kent de mappen en de bestaande filmpjes.

**De bron** is waar het filmpje over gaat: een cursus, een boek, een presentatie, een blogpost,
documentatie. Het onderwerp mag code bevatten, maar dat hoeft niet.

Voor de Remotion-API zelf (interpolate, Sequence, fonts, audio, captions): skill
`remotion-best-practices`. Deze skill gaat over hoe wij het doen.

## 1. Eerst vragen

Stel deze vragen samen in één AskUserQuestion, bij elk nieuw filmpje opnieuw:

1. **Soort clip**: kennisclip of reel. Laat die vraag enkel weg als de gebruiker het soort letterlijk noemt
   ("maak een reel over ...").
2. **Stem**: geen stem (de uitleg staat als tekst in beeld), zelf ingesproken, of een AI-stem.
3. **Ondertitels**: geen, ingebrand in beeld, of een apart `.srt`-bestand.
4. **Bijschrift**: geen, een tekst voor de Instagram-post, of een titel en beschrijving voor het
   platform waar de kennisclip komt.

Wat je met de antwoorden doet, staat in [Stem, ondertitels en bijschrift](#stem-ondertitels-en-bijschrift).

| | Kennisclip | Reel |
|---|---|---|
| Doel | iets uit de bron uitleggen | een verhaal of weetje uit de bron vertellen, voor Instagram |
| Formaat | liggend 1920x1080, 30 fps | staand 1080x1920, 30 fps |
| Duur | 1 tot 3 minuten | 45 tot 60 seconden, **nooit boven 60 s** (een story knipt daar) |
| Opbouw | titelkaart, scènes, afsluiter | haak, verteller met ballon, tekeningen, brugscène, eindkaart |
| Tijd in code | één bestand per scène, `TransitionSeries` met fade | één `tijdlijn.ts` voor het hele filmpje |
| Map | `src/clips/<nn>-<onderwerp>/` | `src/reels/<nn>-<onderwerp>/` |
| Sjabloon | `assets/sjabloon-kennisclip/` | `assets/sjabloon-reel/` |

`<nn>` is de plaats in de bron zoals de kijker ze kent, bv. `h07` voor hoofdstuk 7 of `m2` voor
module 2, niet het nummer van een map in de repo. Heeft de bron geen nummering, laat het dan weg.

**Geen onderwerp opgegeven?** Stel er twee of drie voor met een aanrader, en laat de gebruiker kiezen.

- Kennisclips: zoek onderwerpen zonder clip. Kijk of het project een overzicht van clips per
  onderdeel heeft, of een rapport van wat ontbreekt of verouderd is.
- Reels: zoek anekdotes en weetjes in de bron, vaak in een apart kader of bij een vertellerfiguur.
  Een goed verhaal heeft iets om te tekenen (een trein, een planeet), een getal voor de haak en een
  brug naar de kern van de bron.

## 2. Het Remotion-project

- Zoek eerst een bestaand project: een `remotion.config.ts` met naast zich `src/stijl/project.ts`.
  Gebruik dat, en lees `project.ts`: daar staan de titel, de website, de verteller en de trefwoorden
  van dit project. Kijk ook in `src/clips/` en `src/reels/` wat er al gemaakt is.
- Is er geen, zet er dan een op met de startkit in `assets/`, volgens
  [references/opzet.md](references/opzet.md). Vraag eerst waar het moet komen, en vul `project.ts`
  samen met de gebruiker in.

## 3. De bron lezen

- Lees de volledige tekst waar het filmpje over gaat, niet enkel het stukje dat je wil tonen. De
  uitleg eromheen levert meestal de brugscène en de voorbeelden.
- **Niets verzinnen.** De tekst in ballonnen en onderschriften komt uit de bron, hoogstens ingekort
  of over ballonnen verdeeld. Wat je toevoegt (een factor, een vergelijking, extra code) krijgt een
  comment `// Toegevoegd, niet uit de bron: ...` en komt in je eindbericht.
- **Getallen en uitvoer zijn echt.** Toont het filmpje wat code doet, draai die code dan eerst in de
  scratchpad, in de taal van de bron. Toont het getallen van een generator of algoritme, bouw dat dan
  exact na en vergelijk met de echte uitvoer. Wat je niet kan draaien (een jaartal, een afstand),
  staat letterlijk in de bron.
- Vereenvoudig je iets (elk getal wordt een tegel), zet dan "(sterk vereenvoudigd)" in beeld.
- De schrijfregels van het project (CLAUDE.md, stijlgids) gelden ook voor de tekst in beeld. Geen
  em-dashes.

## 4. Storyboard voorstellen

Kort in de chat: de scènes met hun duur, wat er te zien is, welke zin uit de bron erbij hoort, en wat
er toegevoegd is. Bouw pas na een ja, tenzij de gebruiker al gezegd heeft dat je mag bouwen ("bouw maar",
"maak eens").

## 5. Bouwen

### Voor beide

- Kijk eerst wat er in `src/stijl/` staat: [references/stijl.md](references/stijl.md). Komt iets in een
  tweede filmpje terug, verhuis het dan naar `stijl/` in plaats van het te kopiëren.
- Lees [references/valkuilen.md](references/valkuilen.md) voor je begint te tekenen.
- Registreer de compositie in `src/Root.tsx`: kennisclips in een `Folder` per onderdeel, reels in
  `Reels`. Zet een `render:<naam>`-script in `package.json`.
- Beelden uit de bron (een verteller, een mascotte) kopieer je naar `public/` en toon je met
  `<Img src={staticFile(...)}>`. Pixelart met `imageRendering: "pixelated"`.
- Geef elke rough.js-vorm een eigen seed, en neem per filmpje een eigen blok (bv. 2000 tot 2999).

### Kennisclip

- Kopieer `assets/sjabloon-kennisclip/` naar `src/clips/<naam>/`: `Kennisclip.tsx` (de volgorde en de
  overgangen), `Titel.tsx`, twee voorbeeldscènes en `Afsluiter.tsx`. `S1Schema.tsx` tekent zonder code
  (vlakken, een pijl, een woordje), `S2Werkblad.tsx` toont code en uitvoer. Hou wat past, hernoem de
  componenten en vul in.
- `TransitionSeries` met `fade()` van 15 frames. De duur is de som van de scènes min 15 frames per
  overgang. Eén bestand per scène, met `export const S1_DUUR = ...` bovenaan.
- **Met code**: `Werkblad` uit `stijl/werkblad.tsx`, met de code links in een ruw wit paneel en de
  console rechts.
- **Zonder code**: rough.js-tekeningen zoals in `S1Schema`, tussen y 150 en 870.
- Altijd een `Onderschrift` gecentreerd onderaan (hoogstens twee regels, 4 tot 6 seconden).
- Titelkaart: het onderwerp in Caveat 170 px met een rode onderlijn, eronder één feit. De afsluiter
  toont de titel uit `project.ts` en het onderdeel.

### Reel

- Kopieer `assets/sjabloon-reel/` naar `src/reels/<naam>/`: `tijdlijn.ts` en `Reel.tsx`.
- `tijdlijn.ts` bevat `FASE` (het startframe van elk deel, plus `eind`) en `TEKSTEN` (de ballonteksten,
  elk met `van` en `tot`). Elk onderdeel toont zich met `venster(f, FASE.a, FASE.b)`. Geen
  `TransitionSeries`: zo kan een trein of een sonde gewoon doorlopen van het ene deel naar het andere.
- **Veilige zones**: bovenaan 250 px en onderaan 420 px blijven leeg, net als de rechterrand onderaan.
  Daar zet Instagram de naam, het bijschrift en de knoppen. De ballon staat op y 270 tot 560, de
  tekening tussen y 600 en 1480.
- **Haak**: frame 0 zegt al alles. Een zin met één groot rood getal in een ovaal; de tekst staat er
  meteen, enkel de ovaal tekent zich. Daaronder mag de tekening al zichtbaar zijn.
- **Ballon**: hoogstens 4 regels, van ongeveer 29 tekens met verteller en 36 zonder, 3 tot 5 seconden
  per ballon (90 tot 150 frames). `*nadruk*` wordt rood, `` `code` `` wordt mono.
- **Brugscène**: na het verhaal een korte scène die het aan de kern van de bron koppelt. Gaat de bron
  over code, dan een regel code met zijn uitvoer, zoals in het sjabloon; anders een kernzin of een
  tweede tekening. Daarna de `EindKaart` met het onderdeel en de bron.
- **Groot tekenen.** Een gsm toont die 1080 px op een paar centimeter: een voorwerp van 50 px zie je
  niet, tekst gaat niet onder 34 px.
- Geen muziek in de render. Die zet de gebruiker er in de Instagram-app onder.

## 6. Nakijken

rough.js en Remotion geven geen foutmelding bij een lelijk beeld. Kijken is de enige controle.

1. `npx tsc --noEmit` in de map van het Remotion-project.
2. Stills renderen, op schaal 0.6:

   ```powershell
   foreach ($f in 0, 60, 250, 600, 900) { npx remotion still <id> "out/<naam>-$f.png" --frame=$f --scale=0.6 --log=error }
   ```

   Kies frame 0 (en het frame waarop de ovaal af is), het midden van elke scène of fase, elk moment
   waarop iets verschijnt, botst of omslaat, een frame midden in elke overgang, en de eindkaart.
3. Bekijk elke png met de Read tool en loop [references/checklist.md](references/checklist.md) af.
   Verbeter en render die frames opnieuw.
4. Pas dan het hele filmpje, op de achtergrond (`run_in_background`):
   `npx remotion render <id> out/<naam>.mp4 --log=error`. Kijk de duur na met
   `npx remotion ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1 out/<naam>.mp4`.
   Een reel van meer dan 60 s kort je in.

## 7. Opleveren

- Render een coverbeeld: `npx remotion still <id> out/<naam>-cover.png --frame=<n>` (bij een reel de
  haak met de getekende ovaal, bij een kennisclip de titelkaart).
- Lever mee wat bij de start gevraagd is: de stem zit in de mp4, ondertitels zijn ingebrand of staan in
  `out/<naam>.srt`, het bijschrift staat in `bijschrift.md`.
- Stuur de mp4 en de cover met SendUserFile (`display: "render"`), een `.srt` met `display: "attach"`.
- In je eindbericht: het pad, het formaat en de duur, de opbouw als genummerde lijst, wat uit de bron
  komt en wat toegevoegd is, het render-script, en de tekst van het bijschrift zodat de gebruiker hem meteen kan
  kopiëren.
- **Niets in de bron of op de site zetten.** Waar het filmpje terechtkomt, beslist de gebruiker; een link komt
  er pas bij als die het gepubliceerd heeft.
- `out/` en `node_modules/` horen in `.gitignore`. Commit enkel als de gebruiker erom vraagt.

## Stem, ondertitels en bijschrift

### Stem

- **Geen stem**: de ballonteksten en onderschriften dragen de hele uitleg.
- **Zelf ingesproken**: schrijf na het goedgekeurde storyboard een `script.md` in de map van het
  filmpje, één blok per scène of ballon, in de volgorde van het filmpje. De gebruiker spreekt het in; de
  opnames komen in `public/stem/<naam>/`, één bestand per blok. De definitieve timing bouw je pas
  als die opnames er zijn.
- **AI-stem**: lees `rules/voiceover.md` in `remotion-best-practices` (standaard ElevenLabs). Vraag
  de gebruiker de API-sleutel en zet die enkel in de omgevingsvariabele `ELEVENLABS_API_KEY`, nooit in een
  bestand in de repo. De mp3's komen in `public/stem/<naam>/`.
- Met een stem bepaalt de audio de timing: laat `calculateMetadata` de duur van elke scène uit de
  audio halen (`rules/calculate-metadata.md`, `rules/get-audio-duration.md`) in plaats van vaste
  `S1_DUUR`- of `FASE`-getallen. Wordt een reel zo langer dan 60 s, kort dan de tekst in.
- In een reel blijft de tekst in beeld, ook met een stem: de meeste mensen kijken zonder geluid.

### Ondertitels

- De ondertitels volgen letterlijk wat er gezegd wordt. Zonder stem zijn het de teksten die al in
  beeld staan.
- Werk met captions als JSON van het type `Caption` (`rules/subtitles.md`). Met een stem haal je ze
  uit de audio (`rules/transcribe-captions.md`); zonder stem maak je ze uit de `van` en `tot` van de
  ballonteksten of onderschriften (frames gedeeld door 30, maal 1000 voor milliseconden).
- **Ingebrand**: tonen volgens `rules/display-captions.md`, in Inter (`SANS`). Ze bedekken niets van
  de tekening: in een reel boven de onderste 420 px, in een kennisclip op de plaats van het
  onderschrift, dat dan wegvalt.
- **Apart bestand**: schrijf dezelfde captions weg als `out/<naam>.srt`.

### Bijschrift

- Schrijf het in `bijschrift.md` in de map van het filmpje. Die map zit in git, `out/` niet.
- **Instagram**: twee of drie zinnen in de toon van de bron (geen em-dashes, geen wijze slotzin),
  met het onderdeel, de titel en de website uit `project.ts`, en een handvol hashtags. Vraag de gebruiker welke
  hashtags vast mee moeten.
- **Kennisclip**: een titel en een beschrijving van één of twee zinnen: wat de clip uitlegt en bij welk
  onderdeel van de bron hij hoort.

## Huisstijl (niet wijzigen zonder de gebruiker)

Wil de gebruiker een andere huisstijl, lees dan eerst `LEESMIJ.md`: daar staat wat waar aangepast wordt.

- **Kleuren** in `src/stijl/kleuren.ts`, dezelfde als de Excalidraw-figuren: offwhite achtergrond,
  grijs `#4D4D4D` voor tekst en lijnen, rood `#FF0000` enkel waar het oog heen moet, donkerrood
  `#B30000` voor handgeschreven notities, lichtroze `#FFE5E5` voor markeerstift en arcering. Bij code
  de console als zwart venster met groene tekst en een donker labelbalkje.
- Heeft het project een eigen huisstijl (bv. een `_brand.yml` met andere kleuren), vraag dan of die
  voorgaat. Pas dan enkel `kleuren.ts` aan.
- **Fonts**: Caveat voor alles wat handgeschreven is, JetBrains Mono voor code, Inter voor het
  consolelabel en de ondertitels.
- **Tekeningen** met rough.js, zoals de figuren van de skill `excalidraw-figuur`: roughness 1.1 tot 1.6,
  arcering voor accenten, wit gevuld voor vlakken, geen titels in beeld.
- **Verteller**: heeft de bron een vertellerfiguur of mascotte, dan vertelt die de reels, met zijn
  ballon linksboven. Zonder verteller loopt de ballon over de hele breedte.
- **Beweging**: binnenkomen met `IN`, verplaatsen met `BEWEEG`, een pop met `POP`, weggaan met `WEG`.
  Code verschijnt als typemachine. Nooit CSS-animaties of `Math.random()`.

## Verder

- [references/opzet.md](references/opzet.md): een nieuw Remotion-project opzetten met de startkit.
- [references/stijl.md](references/stijl.md): alles wat in `src/stijl/` staat.
- [references/valkuilen.md](references/valkuilen.md): elk probleem dat al eens opdook, met de oplossing.
- [references/checklist.md](references/checklist.md): wat je op elke still nakijkt.
